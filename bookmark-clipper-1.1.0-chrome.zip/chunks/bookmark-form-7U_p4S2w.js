import{o as e,t}from"./api-Bn-yFoks.js";function n(e){return e.replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`).replace(/'/g,`&#39;`)}function r(e,t){return`
    <label class="cursor-pointer text-[12.5px] rounded-md px-2.5 py-1 border border-line text-ink-soft bg-paper-deeper has-checked:bg-accent has-checked:text-white has-checked:border-accent transition-colors">
      <input type="radio" name="category_id" value="${e}" class="hidden" />
      ${n(t)}
    </label>
  `}function i(e,t){return`
    <label class="cursor-pointer text-[12.5px] rounded-md px-2.5 py-1 border border-line text-ink-soft bg-paper-deeper has-checked:bg-accent has-checked:text-white has-checked:border-accent transition-colors">
      <input type="checkbox" name="tag_ids" value="${e}" class="hidden" />
      ${n(t)}
    </label>
  `}var a=`
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <circle cx="12" cy="12" r="3" />
    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
  </svg>
`;function o(e){e.innerHTML=`<div class="py-10 text-center text-ink-faint text-sm">加载中…</div>`}function s(e,t,r){e.innerHTML=`
    <div class="text-center py-6">
      <div class="font-display font-semibold text-base text-ink mb-2">连接失败</div>
      <p class="text-ink-soft text-[13px] mb-4">${n(t)}</p>
      <button id="bf-open-options" class="px-4 py-2 cursor-pointer bg-accent text-white text-sm rounded-lg hover:bg-accent-ink transition-colors">
        检查设置
      </button>
    </div>
  `,document.getElementById(`bf-open-options`).addEventListener(`click`,r)}function c(e,t){e.innerHTML=`
    <div class="text-center py-6">
      <div class="font-display font-semibold text-base text-ink mb-2">还没有配置服务器</div>
      <p class="text-ink-soft text-[13px] mb-4">需要先填写书签库地址和 API Token</p>
      <button id="bf-open-options" class="px-4 py-2 cursor-pointer bg-accent text-white text-sm rounded-lg hover:bg-accent-ink transition-colors">
        去配置
      </button>
    </div>
  `,document.getElementById(`bf-open-options`).addEventListener(`click`,t)}function l(e){if(e.startsWith(`images/`))return!0;try{let t=new URL(e);return t.protocol===`http:`||t.protocol===`https:`}catch{return!1}}function u(e){return e.title?e.url?l(e.url)?e.cover_image&&!l(e.cover_image)?`封面图片地址格式不正确`:null:`网址格式不正确`:`请填写网址`:`请填写标题`}function d(n){let{container:o,config:s,categories:c,tags:l,initial:d,onOpenOptions:f,onSaved:p}=n;o.innerHTML=`
    <div class="flex items-center justify-between mb-4">
      <div class="font-display font-semibold text-base text-ink">保存到书签库</div>
      <button id="bf-open-options" type="button" class="text-ink-faint cursor-pointer hover:text-ink-soft transition-colors" title="设置" aria-label="设置">
        ${a}
      </button>
    </div>

    <form id="bf-form" class="flex flex-col gap-4">
      <div class="w-full">
        <input id="bf-title" type="text" placeholder="title" required
          class="px-3 py-2 border border-line rounded-lg w-full text-sm text-ink placeholder:text-ink-faint focus:outline-none focus:ring-2 focus:ring-accent focus:border-accent transition-colors" />
      </div>

      <div class="w-full">
        <input id="bf-url" type="text" placeholder="url" required
          class="px-3 py-2 border border-line rounded-lg w-full text-sm text-ink placeholder:text-ink-faint focus:outline-none focus:ring-2 focus:ring-accent focus:border-accent transition-colors" />
      </div>

      <div class="w-full">
        <div class="flex gap-2">
          <input id="bf-cover" type="text" placeholder="cover image"
            class="px-3 py-2 border border-line rounded-lg w-full text-sm text-ink placeholder:text-ink-faint focus:outline-none focus:ring-2 focus:ring-accent focus:border-accent transition-colors" />
          <button type="button" id="bf-upload-btn"
            class="shrink-0 px-3.5 py-2 cursor-pointer bg-paper-deeper hover:bg-paper-deep text-ink-soft hover:text-ink rounded-lg text-sm transition-colors disabled:opacity-50">
            Upload
          </button>
          <input id="bf-cover-file" type="file" accept="image/*" class="hidden" />
        </div>
      </div>

      ${c.length?`<div class="flex flex-wrap gap-1.5">${c.map(e=>r(e.id,e.name)).join(``)}</div>`:``}

      <div class="w-full">
        <input id="bf-new-tags" type="text" placeholder="新增标签（逗号分隔）"
          class="px-3 py-2 border border-line rounded-lg w-full text-sm text-ink placeholder:text-ink-faint focus:outline-none focus:ring-2 focus:ring-accent focus:border-accent transition-colors mb-2" />
        ${l.length?`<div class="flex flex-wrap gap-1.5">${l.map(e=>i(e.id,e.name)).join(``)}</div>`:``}
      </div>

      <textarea id="bf-desc" rows="2" placeholder="desc"
        class="w-full border border-line rounded-lg px-3 py-2 text-sm text-ink placeholder:text-ink-faint focus:outline-none focus:ring-2 focus:ring-accent focus:border-accent transition-colors resize-none"></textarea>

      <div id="bf-status" class="text-sm min-h-4.5"></div>

      <button type="submit" id="bf-submit"
        class="px-4 py-2.5 inline-flex items-center justify-center cursor-pointer bg-accent text-white font-medium text-sm rounded-lg shadow-sm hover:bg-accent-ink transition-colors disabled:opacity-50">
        保存
      </button>
    </form>
  `,document.getElementById(`bf-open-options`).addEventListener(`click`,f);let m=document.getElementById(`bf-title`),h=document.getElementById(`bf-url`),g=document.getElementById(`bf-cover`),_=document.getElementById(`bf-upload-btn`),v=document.getElementById(`bf-cover-file`),y=document.getElementById(`bf-new-tags`),b=document.getElementById(`bf-desc`),x=document.getElementById(`bf-form`),S=document.getElementById(`bf-submit`),C=document.getElementById(`bf-status`);m.value=d.title,h.value=d.url,g.value=d.coverImage;function w(e,t){C.textContent=e,C.className=`text-sm min-h-[18px] `+(t===`ok`?`text-accent-ink`:t===`error`?`text-danger`:`text-ink-soft`)}_.addEventListener(`click`,()=>{v.click()}),v.addEventListener(`change`,async()=>{let t=v.files?.[0];if(t){if(!t.type.startsWith(`image/`)){w(`请选择图片文件`,`error`),v.value=``;return}_.disabled=!0,_.textContent=`上传中…`,w(`正在上传图片…`,`info`);try{let{url:n}=await e(s,t);g.value=n,w(`图片上传成功`,`ok`)}catch(e){w(e instanceof Error?`上传失败：${e.message}`:`图片上传失败`,`error`)}finally{_.disabled=!1,_.textContent=`Upload`,v.value=``}}}),x.addEventListener(`submit`,async e=>{e.preventDefault();let n=x.elements.namedItem(`category_id`)?.value,r=Array.from(x.querySelectorAll(`input[name="tag_ids"]:checked`)),i={title:m.value.trim(),url:h.value.trim(),cover_image:g.value.trim(),category_id:n?Number(n):null,tag_ids:r.map(e=>Number(e.value)),new_tags:y.value.trim(),desc:b.value.trim()},a=u(i);if(a){w(a,`error`);return}S.disabled=!0,w(`保存中…`,`info`);try{await t(s,i),w(`已保存 ✓`,`ok`),p()}catch(e){S.disabled=!1,w(e instanceof Error?e.message:`保存失败，未知错误`,`error`)}})}export{c as i,s as n,o as r,d as t};