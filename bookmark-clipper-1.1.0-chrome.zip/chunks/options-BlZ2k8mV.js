import{a as e,i as t,l as n,s as r,u as i}from"./api-Bn-yFoks.js";var a=document.getElementById(`app`);a.innerHTML=`

  <div class="bg-white border border-line rounded-xl shadow-sm p-6">
    <form id="config-form" class="flex flex-col gap-5">
      <div class="w-full">
        <label class="block font-mono text-[10.5px] uppercase tracking-[0.08em] text-ink-faint mb-1.5">
          书签库地址
        </label>
        <input
          id="server-url"
          type="text"
          placeholder="https://your-domain.com"
          class="px-3.5 py-2.5 border border-line rounded-lg w-full text-sm text-ink placeholder:text-ink-faint focus:outline-none focus:ring-2 focus:ring-accent focus:border-accent transition-colors"
        />
        <p class="text-ink-faint text-xs mt-1.5">不用加结尾的斜杠，比如 https://bm.example.com</p>
      </div>

      <div class="w-full">
        <label class="block font-mono text-[10.5px] uppercase tracking-[0.08em] text-ink-faint mb-1.5">
          用户名
        </label>
        <input
          id="username"
          type="text"
          autocomplete="username"
          placeholder="登录用户名"
          class="px-3.5 py-2.5 border border-line rounded-lg w-full text-sm text-ink placeholder:text-ink-faint focus:outline-none focus:ring-2 focus:ring-accent focus:border-accent transition-colors"
        />
      </div>

      <div class="w-full">
        <label class="block font-mono text-[10.5px] uppercase tracking-[0.08em] text-ink-faint mb-1.5">
          密码
        </label>
        <input
          id="password"
          type="password"
          autocomplete="current-password"
          placeholder="登录密码"
          class="px-3.5 py-2.5 border border-line rounded-lg w-full text-sm text-ink placeholder:text-ink-faint focus:outline-none focus:ring-2 focus:ring-accent focus:border-accent transition-colors"
        />
      </div>

      <div class="w-full">
        <label class="block font-mono text-[10.5px] uppercase tracking-[0.08em] text-ink-faint mb-1.5">
          Token
        </label>
        <input
          id="token"
          type="text"
          readonly
          placeholder="点击下方「生成密钥」自动获取"
          class="px-3.5 py-2.5 border border-line rounded-lg w-full text-sm text-ink-soft bg-paper-deeper placeholder:text-ink-faint focus:outline-none transition-colors"
        />
        <p class="text-ink-faint text-xs mt-1.5">没有服务？访问 <a class="text-accent" href="https://github.com/ikeeplearn/bookmark-axum-askama-htmx" target="_blank">项目仓库</a> 按 README 进行部署</p>
      </div>

      <div id="status" class="text-sm min-h-4.5"></div>

      <div class="flex gap-2">
        <button
          type="submit"
          id="generate-btn"
          class="flex-1 px-4 py-2.5 cursor-pointer inline-flex items-center justify-center bg-accent text-white font-medium text-sm rounded-lg shadow-sm hover:bg-accent-ink transition-colors disabled:opacity-60"
        >
          生成密钥
        </button>
        <button
          type="button"
          id="test-btn"
          class="px-4 py-2.5 cursor-pointer text-ink-soft border border-line rounded-lg text-sm hover:bg-paper-deeper transition-colors"
        >
          测试连接
        </button>
      </div>
    </form>
  </div>
`;var o=document.getElementById(`config-form`),s=document.getElementById(`server-url`),c=document.getElementById(`username`),l=document.getElementById(`password`),u=document.getElementById(`token`),d=document.getElementById(`status`),f=document.getElementById(`test-btn`),p=document.getElementById(`generate-btn`);function m(e,t){d.textContent=e,d.className=`text-sm min-h-4.5 `+(t===`ok`?`text-accent-ink`:t===`error`?`text-danger`:`text-ink-soft`)}function h(e){try{return new URL(e).origin+`/*`}catch{return null}}function g(){p.textContent=u.value.trim()?`重新生成`:`生成密钥`}async function _(){let e=await r();s.value=e.serverUrl,u.value=e.token,g()}o.addEventListener(`submit`,async r=>{r.preventDefault();let a=s.value.trim().replace(/\/+$/,``),o=c.value.trim(),d=l.value;if(!a||!o||!d){m(`服务器地址、用户名和密码都要填`,`error`);return}let f=h(a);if(!f){m(`服务器地址看起来不对，检查一下格式（比如 https://your-domain.com）`,`error`);return}if(!await i.permissions.request({origins:[f]})){m(`没有授权访问这个域名，插件没法连接到服务器`,`error`);return}p.disabled=!0,m(`正在获取密钥…`,`info`);let g=await t({serverUrl:a,username:o,password:d});if(!g.ok||!g.token){p.disabled=!1,m(g.message??`获取密钥失败`,`error`);return}u.value=g.token,await n(a,g.token),l.value=``,m(`正在测试连接…`,`info`);let _=await e({serverUrl:a,token:g.token});m(_?`保存成功，连接正常`:`已保存，但连接测试没通过，检查地址和 Token 是否正确`,_?`ok`:`error`),m(`密钥已获取并保存`,`ok`),p.disabled=!1}),f.addEventListener(`click`,async()=>{let t=s.value.trim().replace(/\/+$/,``),n=u.value.trim();if(!t||!n){m(`服务器地址和 Token 都要填`,`error`);return}m(`正在测试连接…`,`info`);let r=await e({serverUrl:t,token:n});m(r?`连接正常`:`连接失败，检查地址、Token，以及是否已授权访问该域名`,r?`ok`:`error`)}),_();